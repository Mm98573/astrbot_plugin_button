import json
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star
from astrbot.api.message_components import ActionRow, Button, Plain

class MultiButtonPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)

    # 👇 增加 title 参数 👇
    @filter.llm_tool(name="send_multi_buttons")
    async def send_multi_buttons(self, event: AstrMessageEvent, title: str, buttons_data: list):
        """
        发送多个互动回调按钮。用户点击不同的按钮，机器人会直接发送对应的预设回复。
        
        Args:
            title (string): 消息的提示语/标题，告诉用户这些按钮是干嘛的。例如：“请选择你想吃的海鲜：”
            buttons_data (array): 按钮列表。每个元素是一个对象，包含 'label'（按钮文字，最多10字）和 'reply'（点击后要发送的内容）。
        """
        if isinstance(buttons_data, str):
            try:
                buttons_data = json.loads(buttons_data)
            except Exception:
                yield event.plain_result("❌ AI 传入的按钮数据格式有误。")
                return

        if not buttons_data or not isinstance(buttons_data, list):
            yield event.plain_result("❌ 没有提供有效的按钮数据。")
            return

        # 如果 AI 没给标题，给个兜底的默认值
        if not title:
            title = "请点击下方按钮："

        buttons_data = buttons_data[:10]

        rows = []
        current_row_btns = []
        
        for i, item in enumerate(buttons_data):
            if isinstance(item, str):
                label = "按钮"
                reply = item
            else:
                label = str(item.get("label", "未知"))[:10]
                reply = str(item.get("reply", "点击了按钮"))
            
            row_idx = i // 5
            col_idx = i % 5
            btn_id = f"multi_btn_{row_idx}_{col_idx}"
            
            btn = Button(
                id=btn_id,
                label=label,
                style=Button.Style.PRIMARY,
                action=Button.CallbackAction(data=reply)
            )
            current_row_btns.append(btn)
            
            if len(current_row_btns) == 5 or i == len(buttons_data) - 1:
                rows.append(ActionRow(buttons=current_row_btns))
                current_row_btns = []

        # 👇 用 AI 传入的 title 替换写死的文本 👇
        yield event.chain_result([Plain(title)] + rows)

    # ==========================================
    # 静态路由接收器（保持不变）
    # ==========================================
    @filter.button_action("multi_btn_0_0")
    async def btn_0_0(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")

    @filter.button_action("multi_btn_0_1")
    async def btn_0_1(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")

    @filter.button_action("multi_btn_0_2")
    async def btn_0_2(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")

    @filter.button_action("multi_btn_0_3")
    async def btn_0_3(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")

    @filter.button_action("multi_btn_0_4")
    async def btn_0_4(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")

    @filter.button_action("multi_btn_1_0")
    async def btn_1_0(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")

    @filter.button_action("multi_btn_1_1")
    async def btn_1_1(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")

    @filter.button_action("multi_btn_1_2")
    async def btn_1_2(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")

    @filter.button_action("multi_btn_1_3")
    async def btn_1_3(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")

    @filter.button_action("multi_btn_1_4")
    async def btn_1_4(self, event: AstrMessageEvent):
        yield event.plain_result(event.get_button_interaction().data or "无内容")